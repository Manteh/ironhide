import { spawn } from 'child_process';
import { readFile, unlink } from 'fs/promises';
import { unlinkSync, writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { tmpdir } from 'os';
import net from 'net';
import { fileURLToPath } from 'url';
import { getProp, setProp, isMpvRunning as ipcRunning } from './mpv-ipc.js';
import { startTorrent } from './torrent-stream.js';
import { magnetFor } from './torrentio.js';
import { getSettings, STREAM_LANGS } from './settings.js';
import { setPlayState, getPlayState } from './playstate.js';
import { proxied, release as releaseStreamCache } from './streamcache.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const LUA_SCRIPT = join(__dirname, 'mpv-progress.lua');
const MPV_BIN = '/Applications/mpv.app/Contents/MacOS/mpv';

// When the Orbie Mac app is open it plays in its own window (libmpv). Same mpv options, progress script and
// IPC socket as the external player; falls through to the external mpv when the app is not running.
const APP_SOCK = '/tmp/ironhide-app.sock';
function appRunning() {
  return new Promise((resolve) => {
    const s = net.createConnection(APP_SOCK);
    s.once('connect', () => { s.destroy(); resolve(true); });
    s.once('error', () => resolve(false));
  });
}
// Resolves null when the app is not there (play in the external mpv instead), else when playback ends: { status, error? }
function playInApp(url, args, env) {
  return new Promise((resolve) => {
    const sock = net.createConnection(APP_SOCK);
    let started = false, buf = '';
    sock.once('error', () => resolve(started ? { status: 'done', progress: undefined } : null));
    sock.on('connect', () => sock.write(JSON.stringify({ url, args, env }) + '\n'));
    sock.on('data', (d) => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1);
        let ev; try { ev = JSON.parse(line); } catch { continue; }
        if (ev.event === 'started') started = true;
        if (ev.event === 'exit') { sock.destroy(); resolve(ev.error ? { status: 'error', error: ev.error, progress: undefined } : { status: 'done', progress: undefined }); }
      }
    });
    sock.on('close', () => resolve(started ? { status: 'done', progress: undefined } : null));
  });
}

async function resolveUrl(url) {
  const res = await fetch(url, { redirect: 'manual' });
  const location = res.headers.get('location');
  if (location) return { url: location, ready: true };

  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('text/html') || contentType.includes('application/json')) {
    return { url, ready: false };
  }
  return { url, ready: true };
}

async function readProgress(progressFile) {
  try {
    const data = await readFile(progressFile, 'utf-8');
    const parsed = JSON.parse(data.trim());
    await unlink(progressFile).catch(() => {});
    return parsed;
  } catch {
    return null;
  }
}

function formatTime(seconds) {
  if (!seconds || seconds <= 0) return '0m';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m ${s}s`;
}

// The person's audio and subtitle languages, for mpv
async function langArgs() {
  const pb = (await getSettings()).playback, codes = (pb.audioLangs || []).flatMap((c) => STREAM_LANGS[c]?.iso || []);
  const out = [`--alang=${[...new Set([...codes, 'eng', 'en', 'lit', 'lt', 'swe', 'sv'])].join(',')}`];
  if (pb.subLang === 'off') out.push('--sid=no');
  else if (STREAM_LANGS[pb.subLang]) out.push(`--slang=${STREAM_LANGS[pb.subLang].iso.join(',')}`);
  return out;
}

export async function play(stream, subs = []) {
  const progressFile = PROGRESS_FILE;
  const subArgs = subs.flatMap(s => [`--sub-file=${s.path}`]);
  const ipcSocket = '/tmp/ironhide-mpv.sock';
  const mpvArgs = ['--really-quiet', `--script=${LUA_SCRIPT}`, ...(await langArgs()), '--fullscreen=yes', `--input-ipc-server=${ipcSocket}`, ...subArgs];

  let proc;

  if (stream.isRD && stream.url) {
    const resolved = await resolveUrl(stream.url);
    if (!resolved.ready) return { status: 'not_cached' };

    const viaApp = await playInApp(resolved.url, mpvArgs, { IRONHIDE_PROGRESS_FILE: progressFile });
    if (viaApp?.status === 'error') return { status: 'error', error: viaApp.error, progress: await readProgress(progressFile) };
    if (viaApp) return { status: 'done', progress: await readProgress(progressFile) };

    proc = spawn(MPV_BIN, [...mpvArgs, resolved.url], {
      stdio: 'inherit',
      env: { ...process.env, IRONHIDE_PROGRESS_FILE: progressFile },
    });
  } else if (stream.magnet) {
    proc = spawn('/opt/homebrew/bin/webtorrent', [stream.magnet, '--mpv'], {
      stdio: 'inherit',
    });
    return { status: 'playing', progress: null };
  } else if (stream.torrentLink) {
    proc = spawn('/opt/homebrew/bin/webtorrent', [stream.torrentLink, '--mpv'], {
      stdio: 'inherit',
    });
    return { status: 'playing', progress: null };
  } else {
    console.error('No playable URL or magnet link found.');
    process.exit(1);
  }

  return new Promise((resolve) => {
    proc.on('error', (err) => {
      console.error(`Failed to launch player: ${err.message}`);
      resolve({ status: 'error', progress: null });
    });

    proc.on('exit', async () => {
      const progress = await readProgress(progressFile);
      resolve({ status: 'done', progress });
    });
  });
}

const PROGRESS_FILE = '/tmp/ironhide-progress.json';

export function isMpvRunning() {
  return new Promise(resolve => {
    const p = spawn('pgrep', ['-x', 'mpv'], { stdio: 'ignore' });
    p.on('exit', code => resolve(code === 0));
    p.on('error', () => resolve(false));
  });
}

function watchMpvProcess(progressFile, onFinish) {
  let wasRunning = false;
  const interval = setInterval(async () => {
    const running = await isMpvRunning();
    if (running && !wasRunning) wasRunning = true;
    if (!running && wasRunning) {
      clearInterval(interval);
      releaseStreamCache();
      await new Promise(r => setTimeout(r, 400));
      const progress = await readProgress(progressFile);
      if (onFinish) onFinish(progress);
    }
  }, 2000);
  return interval;
}

// Write a shell script and run via osascript so mpv/webtorrent get macOS GUI session access.
// Sets PATH so webtorrent can find mpv internally.
// Uses 'sh scriptPath' to avoid needing chmod +x.
function launchScript(lines) {
  const scriptPath = join(tmpdir(), 'ironhide-launch.sh'); // this user's own temp folder, not the shared /tmp
  writeFileSync(scriptPath, [
    '#!/bin/sh',
    'export PATH=/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH',
    ...lines,
  ].join('\n') + '\n');
  spawn('osascript', ['-e', `do shell script "sh '${scriptPath}'"`], { stdio: 'ignore' });
}

function sh(s) {
  return `'${s.replace(/'/g, "'\\''")}'`;
}

export async function playDetached(stream, subs = [], onFinish, resumeFrom, title) {
  const progressFile = PROGRESS_FILE;
  // Cancel pressed while this was still finding peers or resolving the link: stop before anything starts playing
  const token0 = getPlayState().token, cancelled = () => getPlayState().cancelled === token0;
  const aborted = () => ({ status: 'cancelled', progressFile: null });
  if (cancelled()) return aborted();
  // No debrid link (expired key, uncached, or never set up): stream the torrent from its peers and play the local URL the same way
  let torrent = null;
  if (stream.magnet && !stream.url) {
    setPlayState({ phase: 'launching', detail: 'Finding peers (no debrid)' });
    try { torrent = await startTorrent(stream.magnet, { fileIdx: stream.fileIdx }); }
    catch (e) { if (cancelled()) return aborted(); setPlayState({ phase: 'error', detail: e.message, retry: true }); return { status: 'error', progressFile: null }; }
    if (cancelled()) { torrent.stop(); return aborted(); }
    const done = onFinish; onFinish = (p) => { torrent.stop(); done?.(p); };
    stream = { ...stream, isRD: true, url: torrent.url };
  }
  const ipcSocket = '/tmp/ironhide-mpv.sock';
  // (mpv clears a stale socket itself when it starts. Deleting it here, before anything is known, cut off a player that was
  // still running: another Orbie's, or this one's while a new title was still being looked up.)

  if (stream.isRD && stream.url) {
    const res = await fetch(stream.url, { redirect: 'manual' });
    if (cancelled()) { torrent?.stop(); return aborted(); }
    const location = res.headers.get('location') || (res.status < 300 ? stream.url : null);
    // the debrid link is dead (expired key, not cached): if we know the torrent, stream it from its peers instead
    const viaPeers = () => stream.infoHash && !torrent ? playDetached({ ...stream, isRD: false, url: null, magnet: magnetFor(stream.infoHash) }, subs, onFinish, resumeFrom, title) : null;
    if (!location) { const r = await viaPeers(); if (r) return r; setPlayState({ phase: 'error', detail: 'Stream is not available' }); return { status: 'not_cached', progressFile: null }; }
    if (/failed_|error|denied/i.test(location)) { const r = await viaPeers(); if (r) return r; setPlayState({ phase: 'error', detail: 'Stream is not cached' }); return { status: 'not_cached', progressFile: null }; }
    // through the local caching proxy: one redirect lookup instead of one per seek, and track switches re-read from memory
    const playUrl = await proxied(location);
    if (cancelled()) { torrent?.stop(); return aborted(); }
    setPlayState({ phase: 'launching', detail: 'Starting the player' });

    const mpvArgs = [
      '--really-quiet', `--script=${LUA_SCRIPT}`, ...(await langArgs()),
      // open behind everything, paused, until the stream is buffered; then we reveal it
      '--focus-on=never', '--pause', '--fullscreen=no',
      // buffer far ahead and keep one connection for seeks (the in-app player sets the same; this is for the external mpv)
      '--cache=yes', '--demuxer-seekable-cache=yes', '--demuxer-readahead-secs=120', '--demuxer-max-back-bytes=512MiB', '--cache-pause-wait=0.6',
      '--stream-buffer-size=4MiB', '--demuxer-lavf-o=multiple_requests=1,reconnect=1,reconnect_streamed=1',
      `--input-ipc-server=${ipcSocket}`,
      ...(title ? [`--force-media-title=${title}`] : []),
      ...(resumeFrom > 0 ? [`--start=${Math.floor(resumeFrom)}`] : []),
      ...subs.map(x => `--sub-file=${x.path}`),
      playUrl,
    ];
    // The Mac app plays in its own window: hand the stream over instead of starting an external mpv.
    if (await appRunning()) {
      playInApp(playUrl, mpvArgs.slice(0, -1), { IRONHIDE_PROGRESS_FILE: progressFile }).then(async (r) => {
        // the stream never opened (dead link, refused by the CDN): say so instead of quietly going back
        if (r?.status === 'error') setPlayState({ phase: 'error', detail: r.error || 'The stream could not be opened', retry: true });
        releaseStreamCache();
        await sleep(400);
        if (onFinish) onFinish(await readProgress(progressFile));
      });
      presentWhenReady(getPlayState().token).catch((e) => { console.error('[player] showing mpv failed:', e.message); setPlayState({ phase: 'error', detail: 'The player did not start' }); });
      return { status: 'playing', progressFile, cancel: () => torrent?.stop() };
    }
    try { unlinkSync(ipcSocket); } catch {} // the external mpv is about to take it over
    launchScript([
      `export IRONHIDE_PROGRESS_FILE=${sh(progressFile)}`,
      `nohup /opt/homebrew/bin/mpv ${mpvArgs.map(sh).join(' ')} > /dev/null 2>&1 &`,
    ]);

    const interval = watchMpvProcess(progressFile, onFinish);
    presentWhenReady(getPlayState().token).catch((e) => { console.error('[player] showing mpv failed:', e.message); setPlayState({ phase: 'error', detail: 'The player did not start' }); });
    return { status: 'playing', progressFile, cancel: () => { clearInterval(interval); torrent?.stop(); } };

  } else if (stream.magnet) {
    if (cancelled()) return aborted();
    const wtArgs = [stream.magnet, '--mpv'];
    if (stream.fileIdx != null) wtArgs.push('--select', String(stream.fileIdx));
    if (resumeFrom > 0) wtArgs.push('--player-args', `--start=${Math.floor(resumeFrom)}`);

    launchScript([
      `nohup /opt/homebrew/bin/webtorrent ${wtArgs.map(sh).join(' ')} > /dev/null 2>&1 &`,
    ]);

    const interval = watchMpvProcess(progressFile, onFinish);
    return { status: 'playing', progressFile, cancel: () => clearInterval(interval) };

  } else if (stream.torrentLink) {
    if (cancelled()) return aborted();
    const tlArgs = [stream.torrentLink, '--mpv'];
    if (stream.fileIdx != null) tlArgs.push('--select', String(stream.fileIdx));
    if (resumeFrom > 0) tlArgs.push('--player-args', `--start=${Math.floor(resumeFrom)}`);

    launchScript([
      `nohup /opt/homebrew/bin/webtorrent ${tlArgs.map(sh).join(' ')} > /dev/null 2>&1 &`,
    ]);

    const interval = watchMpvProcess(progressFile, onFinish);
    return { status: 'playing', progressFile, cancel: () => clearInterval(interval) };

  } else {
    return { status: 'error', progressFile: null };
  }
}

export { readProgress, formatTime };


const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Wait until mpv has the file open and a few seconds buffered, then unpause,
// go fullscreen and raise the window so the hand-over is seamless.
export async function presentWhenReady(token) {
  const t0 = Date.now();
  const stale = () => getPlayState().token !== token || getPlayState().phase === 'idle';
  let seenWindow = false;
  while (Date.now() - t0 < 60000) {
    await sleep(500);
    if (stale()) return;
    if (!ipcRunning()) { if (Date.now() - t0 > 12000) break; continue; }
    seenWindow = true;
    const dur = await getProp('duration').catch(() => null);
    if (!(dur > 0)) continue;
    setPlayState({ phase: 'buffering', detail: 'Buffering' });
    const [cache, pos] = await Promise.all([getProp('demuxer-cache-time').catch(() => 0), getProp('time-pos').catch(() => 0)]);
    if ((cache || 0) - (pos || 0) >= 3 || Date.now() - t0 > 35000) break;
  }
  if (stale()) return;
  if (!seenWindow || !ipcRunning()) { setPlayState({ phase: 'error', detail: 'The player did not start' }); return; }
  setPlayState({ phase: 'playing', detail: 'Starting playback' });
  await setProp('pause', false).catch(() => {});
  // bring to front: toggling ontop raises the window without needing extra permissions
  await setProp('ontop', true).catch(() => {});
  await sleep(250);
  await setProp('ontop', false).catch(() => {});
  setTimeout(() => { if (getPlayState().token === token && getPlayState().phase === 'playing') setPlayState({ detail: 'Playing' }); }, 1200);
}
